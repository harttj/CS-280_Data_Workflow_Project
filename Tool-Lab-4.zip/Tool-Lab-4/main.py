from fastapi import FastAPI, File, UploadFile
from PIL import Image
from io import BytesIO
import numpy as np
import cv2
from slowapi.errors import RateLimitExceeded
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from starlette.requests import Request
from starlette.responses import Response
import tensorflow as tf
from tensorflow import keras

limiter = Limiter(key_func=get_remote_address)
app = FastAPI()
app.state.limiter = limiter 
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
# str_labels = ['apple', 'aquarium_fish', 'baby', 'bear', 'beaver', 'bed', 'bee', 'beetle', 'bicycle', 'bottle', 'bowl', 'boy', 'bridge', 'bus', 'butterfly', 'camel', 'can', 'castle', 'caterpillar', 'cattle', 'chair', 'chimpanzee', 'clock', 'cloud', 'cockroach', 'couch', 'crab', 'crocodile', 'cup', 'dinosaur', 'dolphin', 'elephant', 'flatfish', 'forest', 'fox', 'girl', 'hamster', 'house', 'kangaroo', 'keyboard', 'lamp', 'lawn_mower', 'leopard', 'lion', 'lizard', 'lobster', 'man', 'maple_tree', 'motorcycle', 'mountain', 'mouse', 'mushroom', 'oak_tree', 'orange', 'orchid', 'otter', 'palm_tree', 'pear', 'pickup_truck', 'pine_tree', 'plain', 'plate', 'poppy', 'porcupine', 'possum', 'rabbit', 'raccoon', 'ray', 'road', 'rocket', 'rose', 'sea', 'seal', 'shark', 'shrew', 'skunk', 'skyscraper', 'snail', 'snake', 'spider', 'squirrel', 'streetcar', 'sunflower', 'sweet_pepper', 'table', 'tank', 'telephone', 'television', 'tiger', 'tractor', 'train', 'trout', 'tulip', 'turtle', 'wardrobe', 'whale', 'willow_tree', 'wolf', 'woman', 'worm']

@app.get("/")
@limiter.limit("5/minute")
async def root(request: Request, response: Response):
  firstName = 'TJ'
  lastName = 'Hart'
  return {"api_info": f"{firstName} - {lastName}'s CS280 Image Classifier"}

# This is a post request that allows you to receive a file:
@app.post("/classify/")
@limiter.limit("15/minute")
async def classify(request: Request, response: Response, file: UploadFile = File(...)):
    fileContent = file.read() # Reads file information from request as a stream of bytes
    bytesfile  = BytesIO(file.file.read())
    image = Image.open(bytesfile) # Converts file to a python image from a stream of bytes.
    imageArray = np.asarray(image) #converts image to numpy array
    print(imageArray.shape)
    smallImage = cv2.resize(imageArray, dsize=(32, 32), interpolation=cv2.INTER_CUBIC) # Resizes the image
    batchedImage = np.expand_dims(smallImage, axis=0)

    model = keras.models.load_model("trainedModel.h5")

    yhat = np.argmax(model.predict(batchedImage))

    return { "classification": f"{yhat}"}
    # return batchedImage
    # return {"File Name": f"{file.filename}"} # Returns the filename as a response.
